import React, { useState } from 'react'
import { AddCategory } from './components/AddCategory'

export const GifExpertApp = () => {

    // const categories = ['One punch','Samurai X','Dragon ball'];
    const [categories, setcategories] = useState(['One punch'])
     
    return (
        <>
          <h2>GifExpertApp</h2>
          <hr/> 
          <AddCategory setcategories = {setcategories} />
          
          <ol>
              {
                  categories.map(
                      category=>{
                          return <li key={category}>{category}</li> 
                      }
                  )
              }
          </ol>
        </>
    )
}
