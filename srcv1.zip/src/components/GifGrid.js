import React from 'react'

export const GifGrid = ({category}) => {
    return (
        <div>
            <h3>{category}</h3>
        </div>
    )
}
